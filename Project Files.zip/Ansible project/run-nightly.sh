
# Wrapper gets a clean environment and a single log file per run.
set -euo pipefail

PROJECT_DIR="/opt/ansible-homelab"
LOG_DIR="/var/log/ansible-reports"
DATE=$(date +%F)

mkdir -p "$LOG_DIR"
cd "$PROJECT_DIR"

echo "=== Nightly run started: $(date) ===" >> "$LOG_DIR/nightly-$DATE.log"
ansible-playbook site.yml >> "$LOG_DIR/nightly-$DATE.log" 2>&1
echo "=== Nightly run finished: $(date) ===" >> "$LOG_DIR/nightly-$DATE.log"

